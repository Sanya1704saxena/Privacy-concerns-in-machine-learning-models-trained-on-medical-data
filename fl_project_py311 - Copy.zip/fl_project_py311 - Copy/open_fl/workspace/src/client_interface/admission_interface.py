import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from model_1 import  MLP  # Adjusted import to match the new structure

import yaml
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import LabelEncoder, StandardScaler


class AdmissionClient:  # Removed TaskInterface inheritance
    def __init__(self):
        df = pd.read_csv(r'C:\Users\dell\Downloads\fl_project_py311\open_fl\workspace\data\admission_preprocessed.csv')

        categorical_cols = ['admission_location_mapped', 'discharge_location_mapped',
                            'admission_type_retained', 'admittime_generalized', 'dischtime_generalized',
                            'marital_status', 'ethnicity', 'religion', 'language', 'insurance', 'diagnosis']

        df[categorical_cols] = df[categorical_cols].apply(lambda col: LabelEncoder().fit_transform(col.astype(str)))

        features = df.drop(columns=['hospital_expire_flag', 'row_id', 'subject_id', 'hadm_id'])
        labels = df['hospital_expire_flag'].values.astype('float32')

        scaler = StandardScaler()
        features = scaler.fit_transform(features)

        X = torch.tensor(features, dtype=torch.float32)
        y = torch.tensor(labels.reshape(-1, 1), dtype=torch.float32)

        dataset = TensorDataset(X, y)
        self.train_loader = DataLoader(dataset, batch_size=32, shuffle=True)

        self.model = MLP(input_dim=X.shape[1])
        self.criterion = nn.BCELoss()
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.001)

    def get_model(self):
        return self.model

    def train(self, num_epochs=7):
        self.model.train()
        for epoch in range(num_epochs):
            for X_batch, y_batch in self.train_loader:
                self.optimizer.zero_grad()
                outputs = self.model(X_batch)
                loss = self.criterion(outputs, y_batch)
                loss.backward()
                self.optimizer.step()
        print("✅ Training completed")

    def evaluate(self):
        self.model.eval()
        total_loss = 0.0
        total_samples = 0
        correct = 0
        with torch.no_grad():
            for X_batch, y_batch in self.train_loader:
                outputs = self.model(X_batch)
                loss = self.criterion(outputs, y_batch)
                total_loss += loss.item() * y_batch.size(0)
                preds = (outputs > 0.5).float()
                correct += (preds == y_batch).sum().item()
                total_samples += y_batch.size(0)
        avg_loss = total_loss / total_samples
        accuracy = correct / total_samples
        return {'avg_loss': round(avg_loss, 4), 'accuracy': round(accuracy, 4)}

    def save_model(self, filepath):
        torch.save(self.model.state_dict(), filepath)

    def load_model(self, filepath):
        self.model.load_state_dict(torch.load(filepath))
